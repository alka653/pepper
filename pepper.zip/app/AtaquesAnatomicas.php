<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AtaquesAnatomicas extends Model
{
    //
}
