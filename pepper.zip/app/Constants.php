<?php

namespace App;

class Constants{
	const TIPO_DOCUMENTO_LISTA = ['C', 'P', 'D'];
}