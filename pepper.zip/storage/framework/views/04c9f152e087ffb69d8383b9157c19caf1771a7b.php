<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 100px">
		<div class="block">
			<h2>Edición de datos personales</h2>
			<div class="row">
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>