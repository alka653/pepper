<header id="header">
	<div class="container">
		<div id="logo" class="pull-left">
			<h1>
				<a href="<?php echo e(route('home')); ?>" class="scrollto">
					<img src="/img/img.jpg" height="60px">
				</a>
			</h1>
		</div>
		<nav id="nav-menu-container">
			<ul class="nav-menu sf-js-enabled sf-arrows">
				<li>
					<a href="<?php echo e(route('home')); ?>">Inicio</a>
				</li>
				<?php if(!Auth::check()): ?>
					<li>
						<a href="<?php echo e(route('quienes_somos')); ?>">Quienes somos</a>
					</li>
					<li>
						<a href="<?php echo e(route('listar_razas_without_auth')); ?>">Razas</a>
					</li>
					<li>
						<a href="<?php echo e(route('acerca')); ?>" class="open-modal">Acerca de</a>
					</li>
					<li>
						<a href="<?php echo e(route('ley_746')); ?>">Ley 746</a>
					</li>
					<li>
						<a href="<?php echo e(route('login')); ?>">Iniciar sesión</a>
					</li>
				<?php else: ?>
					<?php echo $__env->make('elements.nav_list_'.(Auth::user()->perfil != 'U' ? 'A' : Auth::user()->perfil), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<li class="menu-has-children">
						<a href="#">
							<div class="row align-items-center">
								<div class="col-3">
									<img src="<?php echo e(Auth::user()->persona->foto); ?>" width="25">
								</div>
								<div class="col-9">
									<?php echo e(Auth::user()->persona->nombre); ?>, <?php echo e(Auth::user()->getPerfil(Auth::user()->perfil)); ?>

								</div>
							</div>
						</a>
						<ul>
							<li>
								<a href="<?php echo e(route('perfil')); ?>">Mi cuenta</a>
							</li>
							<li>
								<a href="<?php echo e(route('logout')); ?>">Cerrar sesión</a>
							</li>
						</ul>
					</li>
				<?php endif; ?>	
			</ul>
		</nav>
	</div>
</header>