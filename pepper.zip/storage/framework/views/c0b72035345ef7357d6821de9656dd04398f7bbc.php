<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 100px;">	
		<h2 class="no-margin">
			Solicitud de certificado para <?php echo e($solicitud->mascota->nombre); ?>

			<small><?php echo $solicitud->getEstado($solicitud->estado); ?></small>
			<?php if(Auth::user()->perfil == 'U' && $solicitud->estado == 'P'): ?>
				<small>
					<a href="<?php echo e(route('editar_solicitud', ['solicitud' => $solicitud->id])); ?>" class="btn btn-warning btn-sm">Editar</a>
				</small>
			<?php endif; ?>
		</h2>
		<p class="no-margin">
			<b>Fecha de solicitud:</b>
			<?php echo e($solicitud->fecha_solicitud); ?>

		</p>
		<p>
			<b>Propietario:</b>
			<?php echo e($solicitud->mascota->propietario->nombre.' '.$solicitud->mascota->propietario->apellido); ?>

		</p>
		<div class="row justify-content-md-center">
			<?php $__currentLoopData = $solicitud->documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4">
					<div class="block">
						<a href="<?php echo e(Storage::url($documento->documento)); ?>" target="_blank">
							<?php echo e($documento->tipo); ?>

						</a>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<br>
		<h4>Revisiones</h4>
		<div class="block">
			<?php if($solicitud->estado == 'F' && Auth::user()->perfil == 'U'): ?>
				<div class="alert alert-success">
					La solicitud ha sido aprobada. Puede descargarlo <a href="#">aquí</a>
				</div>
			<?php endif; ?>
			<?php if(!auth()->check() || ! auth()->user()->hasRole('guest')): ?>
				<?php if($solicitud->revisionesInspector($solicitud->id, Auth::user()->id)->count() == 0 && $solicitud->estado == 'P'): ?>
					<?php echo e(Form::model($revisionModel, ['route' => ['crear_revision.post', $solicitud->id], 'method' => 'post', 'autocomplete' => 'off'])); ?>

						<div class="form-group">
							<?php echo e(Form::label('observacion', 'Observación', ['class' => 'label-required'])); ?>

							<?php echo e(Form::textarea('observacion', null, ['required', 'rows' => 2, 'class' => 'form-control'])); ?>

						</div>
						<?php ($revisiones = $solicitud->revisionesInspector($solicitud->id)); ?>
						<?php ($revisionesFinale = $solicitud->revisionesInspector($solicitud->id, null, 'P')); ?>
						<?php if($revisiones->count() == 0 || ($revisionesFinale->count() > 0 && $revisionesFinale->first()->modo < 3) || (Auth::user()->perfil != 'J' && $revisionesFinale->count() == 0)): ?>
							<div class="form-group">
								<?php echo e(Form::label('remitir', '¿Remitir al siguiente inspector?', ['class' => 'label-required'])); ?>

								<?php echo e(Form::select('remitir', [
									'' => 'Seleccione una opción',
									'N' => 'No',
									'S' => 'Si'
								], null, ['required', 'class' => 'form-control'])); ?>

							</div>
						<?php else: ?>
							<div class="form-group">
								<?php echo e(Form::label('certificado', '¿Aceptar certificado?', ['class' => 'label-required'])); ?>

								<?php echo e(Form::select('certificado', [
									'' => 'Seleccione una opción',
									'N' => 'No',
									'S' => 'Si'
								], null, ['required', 'class' => 'form-control'])); ?>

							</div>
						<?php endif; ?>
						<div class="form-group text-center">
							<?php echo Form::button('Enviar datos', ['type' => 'submit', 'class' => 'btn btn-sm btn-primary']); ?>

						</div>
					<?php echo e(Form::close()); ?>

				<?php else: ?>
					<div class="alert alert-warning">
						Ya has realizado la revisión
					</div>
				<?php endif; ?>
			<?php endif; ?>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Fecha</th>
							<th>Inspector</th>
							<th>Observación</th>
							<th>Estado</th>
							<?php if(!auth()->check() || ! auth()->user()->hasRole('guest')): ?>
								<th></th>
							<?php endif; ?>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $solicitud->revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<?php if($revision->inspector_id != null): ?>
								<tr>
									<td><?php echo e($revision->fecha); ?></td>
									<td><?php echo e($revision->inspector->persona->nombre.' '.$revision->inspector->persona->apellido); ?></td>
									<td><?php echo e($revision->observacion); ?></td>
									<td><?php echo e($revision->getEstado($revision->estado)); ?></td>
									<?php if(!auth()->check() || ! auth()->user()->hasRole('guest')): ?>
										<td>
											<a href="<?php echo e(route('editar_revision', ['solicitud' => $revision->solicitud_id, 'revision' => $revision->id])); ?>" class="btn btn-warning open-modal">Editar</a>
										</td>
									<?php endif; ?>
								</tr>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr class="text-center">
								<td colspan="<?php if(!auth()->check() || ! auth()->user()->hasRole('guest')): ?> 5 @elseunlessrole  4 <?php endif; ?>">Sin revisiones</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>