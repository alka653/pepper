<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 100px">
		<div class="block">
			<div class="row">
				<div class="col-md-2 text-center">
					<div class="row">
						<div class="col-12">
							<img src="<?php echo e($usuario->persona->foto); ?>" class="img-fluid rounded" alt="<?php echo e($usuario->persona->nombre); ?>">
						</div>	
						<div class="col-12">
							<h5 class="no-margin">
								<?php echo e($usuario->persona->nombre.' '.$usuario->persona->apellido); ?>

							</h5>
						</div>
					</div>
				</div>
				<div class="col-md-10">
					<h5 class="no-margin">
						<b>Correo electrónico:</b>
						<?php echo e($usuario->email); ?>

					</h5>
					<h5 class="no-margin">
						<b>Tipo de documento:</b>
						<?php echo e($usuario->persona->getTipoDocumento($usuario->persona->tipo_documento)); ?>

					</h5>
					<h5 class="no-margin">
						<b>Número de documento:</b>
						<?php echo e(number_format($usuario->persona->numero_documento)); ?>

					</h5>
					<h5 class="no-margin">
						<b>Lugar expedición documento:</b>
						<?php echo e($usuario->persona->lugar($usuario->persona->municipio_expedicion_id)); ?>

					</h5>
					<h5 class="no-margin">
						<b>Dirección de residencia:</b>
						<?php echo e($usuario->persona->direccion_residencia); ?>. <?php echo e($usuario->persona->lugar($usuario->persona->municipio_residencia_id)); ?>

					</h5>
					<h5 class="no-margin">
						<b>Sexo:</b>
						<?php echo e($usuario->persona->getSexo($usuario->persona->sexo)); ?>

					</h5>
					<h5 class="no-margin">
						<b>Número celular:</b>
						<?php echo e($usuario->persona->numero_celular); ?>

					</h5>
					<h5 class="no-margin">
						<b>Número telefonico:</b>
						<?php echo e($usuario->persona->numero_telefonico); ?>

					</h5>
					<h5 class="no-margin">
						<b>Ocupación:</b>
						<?php echo e($usuario->persona->ocupacion); ?>

					</h5>
					<div class="text-center">
						<a href="<?php echo e(route('editar_perfil', ['persona' => $usuario->persona_id])); ?>" class="btn btn-sm btn-success">
							Actualizar datos
						</a>
						<a href="<?php echo e(route('cambiar_password')); ?>" class="btn btn-sm btn-warning open-modal">
							Cambiar contraseña
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>