<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 50px">
		<h2>
			Lista de mascotas
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear_mascota')): ?>
				<a href="<?php echo e(route('crear_mascota')); ?>" class="btn btn-primary btn-sm" style="margin-top: 10px; margin-bottom: 10px;">Agregar mascota</a>
			<?php endif; ?>
		</h2>
		<?php echo $__env->make('elements.buscar', ['extra' => 'mascotas.filters'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="block">
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Mascota</th>
							<th>Género</th>
							<th>Raza</th>
							<?php if(!auth()->check() || ! auth()->user()->hasRole('guest')): ?>
								<th>Propietario</th>
							<?php endif; ?>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($mascota->nombre); ?></td>
								<td><?php echo e($mascota->getSexo($mascota->sexo)); ?></td>
								<td><?php echo e($mascota->raza->nombre); ?></td>
								<?php if(!auth()->check() || ! auth()->user()->hasRole('guest')): ?>
									<td><?php echo e($mascota->propietario_id != null ? $mascota->propietario->nombre.' '.$mascota->propietario->apellido : 'Sin propietario'); ?></td>
								<?php endif; ?>
								<td>
									<a href="<?php echo e(route('detalle_mascota', ['mascota' => $mascota->id])); ?>" class="btn btn-sm btn-info">Detalle</a>
									<a href="<?php echo e(route('editar_mascota', ['mascota' => $mascota->id])); ?>" class="btn btn-sm btn-warning">Editar</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<?php if(auth()->check() && auth()->user()->hasRole('guest')): ?>
									<td colspan="4">
										No se encuentra la mascota agregada. Da <a href="<?php echo e(route('crear_mascota')); ?>">clic aquí</a> para agregar una mascota
									</td>
								<?php else: ?>
									<td colspan="5">
										No se enontraron resultados
									</td>
								<?php endif; ?>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php echo e($mascotas->links()); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>