<?php echo e(Form::open(['url' => $url, 'method' => 'get', 'class' => 'row'])); ?>

	<div class="col-11">
		<?php echo e(Form::text('query', $query, ['placeholder' => $placeholder, 'class' => 'form-control'])); ?>

	</div>
	<div class="col-1">
		<?php echo Form::button('<i class="fa fa-search"></i>', ['type' => 'submit', 'class' => 'btn btn-default']); ?>

	</div>
	<?php if(isset($extra)): ?>
		<?php echo $__env->make($extra, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
<?php echo e(Form::close()); ?>