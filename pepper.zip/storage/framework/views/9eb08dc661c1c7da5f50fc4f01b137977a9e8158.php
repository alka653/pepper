<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 50px">
		<h2>Mis mascotas</h2>
		<div class="row justify-content-md-center">
			<div class="col-12 text-center">
				<?php echo $__env->make('elements.buscar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<a href="<?php echo e(route('crear_mascota')); ?>" class="btn btn-primary btn-sm" style="margin-top: 10px; margin-bottom: 10px;">Agregar mascota</a>
			</div>
			<?php $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4 block">
					<div class="row">
						<div class="col-3">
							<img src="<?php echo e(Storage::url($mascota->fotos[0]->foto)); ?>" alt="<?php echo e($mascota->nombre); ?>" class="img-fluid rounded">
						</div>
						<div class="col-9">
							<h3 class="no-margin"><?php echo e($mascota->nombre); ?></h3>
							<h6 class="no-margin"><b>Sexo:</b> <?php echo e($mascota->getSexo($mascota->sexo)); ?></h6>
							<?php if(Auth::user()->perfil != 'U'): ?>
								<h6 class="no-margin"><b>Propietario:</b> <?php echo e($mascota->propietario->nombre.' '.$mascota->propietario->apellido); ?></h6>
							<?php endif; ?>
							<a href="<?php echo e(route('detalle_mascota', ['mascota' => $mascota->id])); ?>" class="btn btn-sm btn-info">Detalle</a>
							<a href="<?php echo e(route('editar_mascota', ['mascota' => $mascota->id])); ?>" class="btn btn-sm btn-warning">Editar</a>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>