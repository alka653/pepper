<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<h2>
			Lista de solicitudes
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear_solicitud')): ?>
				<small>
					<a href="<?php echo e(route('crear_solicitud')); ?>" class="btn btn-sm btn-success">Crear solicitud</a>
				</small>
			<?php endif; ?>
		</h2>
		<div class="block">
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Fecha solicitud</th>
							<th>Fecha finalizado</th>
							<th>Mascota</th>
							<?php if(!auth()->check() || ! auth()->user()->hasRole('guest')): ?>
								<th>Propietario</th>
							<?php endif; ?>
							<th>Estado</th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($solicitud->fecha_solicitud); ?></td>
								<td><?php echo e($solicitud->fecha_finalizado); ?></td>
								<td><?php echo e($solicitud->mascota->nombre); ?></td>
								<?php if(!auth()->check() || ! auth()->user()->hasRole('guest')): ?>
									<td><?php echo e($solicitud->mascota->propietario->nombre.' '.$solicitud->mascota->propietario->apellido); ?></td>
								<?php endif; ?>
								<td><?php echo $solicitud->getEstado($solicitud->estado); ?></td>
								<td>
									<a href="<?php echo e(route('detalle_solicitud', ['solicitud' => $solicitud->id])); ?>" class="btn btn-primary btn-sm">Ver solicitud</a>
									<?php if(Auth::user()->perfil == 'U' && $solicitud->estado == 'P'): ?>
										<a href="<?php echo e(route('editar_solicitud', ['solicitud' => $solicitud->id])); ?>" class="btn btn-warning btn-sm">Editar</a>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr class="text-center">
								<td colspan="<?php if(auth()->check() && auth()->user()->hasRole('guest')): ?> 5 <?php else: ?> 6 <?php endif; ?>">
									<?php if(auth()->check() && auth()->user()->hasRole('guest')): ?>
										No se han encontrado solicitudes. Da <a href="<?php echo e(route('crear_solicitud')); ?>">clic aquí</a> para realizar el trámite
									<?php else: ?>
										Aún no han realizado solicitudes
									<?php endif; ?>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php echo e($solicitudes->links()); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>