<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container text-center" style="margin-top: 10%; margin-bottom: 50px;">
		<h1>Algo ha ocurrido!</h1>
		<h4>Parece que no tienes acceso al recurso en pantalla. Si crees que se trata de un error, contacta al admnistrador.</h4>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>