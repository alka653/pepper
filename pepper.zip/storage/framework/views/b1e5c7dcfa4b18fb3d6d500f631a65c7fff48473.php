Hola, <?php echo e($user->nombre); ?> <?php echo e($user->apellido); ?>


Gracias por registrarse en Pepper.
Recuerda que el correo es <?php echo e($user->email); ?> y la contraseña es 12345.
Ingresa ya para registrar a una mascota.

<?php echo e(route('login')); ?>