<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 50px">
		<h2>
			Lista de ataques registrados
			<small>
				<a href="<?php echo e(route('registrar_ataque')); ?>" class="btn btn-sm btn-primary">Registrar ataque</a>
			</small>
		</h2>
		<div class="block">
			<div class="table-responsive">
				<table class="table table-striped table-sm">
					<thead>
						<tr>
							<th>Fecha</th>
							<th>Paciente</th>
							<th>Especie agresora</th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $ataques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ataque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($ataque->fecha_ataque); ?></td>
								<td><?php echo e($ataque->victima->nombre.' '.$ataque->victima->apellido); ?></td>
								<td><?php echo e($ataque->agresorRaza($ataque->mascota->raza_id)->nombre); ?></td>
								<td>
									<a href="<?php echo e(route('detalle_ataque', ['ataque' => $ataque->id])); ?>" class="btn btn-sm btn-success">Ver detalle</a>
									<a href="<?php echo e(route('seguimiento_ataque', ['ataque' => $ataque->id])); ?>" class="btn btn-sm btn-info">Seguimiento</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="4" class="text-center">
									No hay registro de ataques
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php echo e($ataques->links()); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>