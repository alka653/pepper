<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
	<link href="https://unpkg.com/gijgo@1.9.11/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 100px">
		<h2>
			Realiza un seguimiento
			<small>
				<a href="<?php echo e(route('detalle_ataque', ['ataque' => $ataque->id])); ?>" class="btn btn-sm btn-info">Ver detalle</a>
				<a href="<?php echo e(route('crear_seguimiento_ataque', ['ataque' => $ataque->id])); ?>" class="btn btn-sm btn-success open-modal">Realizar seguimiento</a>
			</small>
		</h2>
		<div class="block" style="margin-top: 10px; padding: 0">
			<div class="block-title p-2">
				Datos básicos del ataque
			</div>
			<div class="p-2">
				<div class="row align-items-center">
					<div class="col-md-5">
						<p class="no-margin">
							<b>Nombres y apellidos del paciente</b>
						</p>
						<p class="no-margin"><?php echo e($ataque->victima->nombre.' '.$ataque->victima->apellido); ?></p>
					</div>
					<div class="col-md-5">
						<p class="no-margin">
							<b>Nombres y apellidos del propietario del atacante</b>
						</p>
						<p class="no-margin"><?php echo e($ataque->mascota->propietario->nombre); ?> <?php echo e($ataque->mascota->propietario->apellido); ?></p>
					</div>
					<div class="col-md-2">
						<p class="no-margin">
							<b>Fecha del ataque</b>
						</p>
						<p class="no-margin">
							<?php echo e(date('d/m/Y', strtotime($ataque->fecha_ataque))); ?>

						</p>
					</div>
				</div>
			</div>
		</div>
		<?php $__empty_1 = true; $__currentLoopData = $ataque->seguimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seguimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="block">
				<?php echo $seguimiento->descripcion; ?>

				<small class="pull-right">
					<span class="badge badge-light"><?php echo e($seguimiento->fecha); ?></span>
					<span class="badge badge-dark"><?php echo e($seguimiento->getTipo($seguimiento->tipo)); ?></span>
					<a href="<?php echo e(route('editar_seguimiento_ataque', ['ataque' => $ataque->id, 'seguimmiento' => $seguimiento->id])); ?>" class="btn btn-sm btn-warning open-modal">Editar</a>
					<a href="<?php echo e(route('eliminar_seguimiento_ataque', ['ataque' => $ataque->id, 'seguimmiento' => $seguimiento->id])); ?>" class="btn btn-sm btn-danger open-modal">Eliminar</a>
				</small>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div class="text-center">
				<h5>Aun no han realizado el seguimiento al ataque registrado. Da <a href="<?php echo e(route('crear_seguimiento_ataque', ['ataque' => $ataque->id])); ?>" class="open-modal">clic aquí</a> para empezar el seguimiento.</h5>
			</div>
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script defer async src="https://unpkg.com/gijgo@1.9.11/js/gijgo.min.js" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>