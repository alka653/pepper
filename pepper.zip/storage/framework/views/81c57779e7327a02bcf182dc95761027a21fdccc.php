<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 50px">
		<h2>Lista de razas</h2>
		<div class="row justify-content-md-center">
			<div class="col-12 text-center">
				<?php echo $__env->make('elements.buscar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<br>
				<a href="<?php echo e(route('crear_raza')); ?>" class="btn btn-primary btn-sm open-modal" style="margin-top: 10px; margin-bottom: 10px;">Agregar raza</a>
			</div>
			<div class="col-12">
				<div class="block">
					<div class="table-responsive">
						<table class="table table-striped">
							<thead>
								<tr>
									<th>Raza</th>
									<th>Especie</th>
									<th></th>
								</tr>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $razas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<tr>
										<td><?php echo e($raza->nombre); ?></td>
										<td><?php echo e($raza->getEspecie($raza->especie)); ?></td>
										<td>
											<a href="<?php echo e(route('editar_raza', ['raza' => $raza->id])); ?>" class="btn btn-sm btn-warning open-modal">Editar</a>
											<a href="<?php echo e(route('eliminar_raza', ['raza' => $raza->id])); ?>" class="btn btn-sm btn-danger open-modal">Eliminar</a>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<tr class="text-center">
										<td colspan="3">
											Aún no hay razas registradas
										</td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="col-12">
				<?php echo e($razas->links()); ?>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>