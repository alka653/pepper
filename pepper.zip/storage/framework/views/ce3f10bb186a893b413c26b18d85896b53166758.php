<li class="menu-has-children">
	<a href="#" class="sf-with-ul">Mascotas</a>
	<ul>
		<li>
			<a href="<?php echo e(route('crear_mascota')); ?>">Crear</a>
		</li>
		<li>
			<a href="<?php echo e(route('listar_mascota')); ?>">Listar</a>
		</li>
	</ul>
</li>
<li class="menu-has-children">
	<a href="#" class="sf-with-ul">Solicitudes</a>
	<ul>
		<li>
			<a href="<?php echo e(route('crear_solicitud')); ?>">Crear</a>
		</li>
		<li>
			<a href="<?php echo e(route('listar_solicitudes')); ?>">Listar</a>
		</li>
	</ul>
</li>