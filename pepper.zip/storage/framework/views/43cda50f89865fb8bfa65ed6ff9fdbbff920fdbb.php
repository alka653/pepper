<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
	<link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/portafolio.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 100px">
		<h2 class="text-center">Perros potencialmente peligrosos</h2>
		<section class="portafolio">
			<div class="portafolio-container">
				<div class="row">
					<?php $__currentLoopData = $razas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4" style="margin: 5px 0px">
							<section class="portafolio-item text-center">
								<img src="<?php echo e($raza->image); ?>" class="img-fluid">
								<section class="portafolio-text">
									<h2 style="color:#00BFFF; font-size:18px;: Georgia, 'Times New Roman', serif;"><b><?php echo e($raza->nombre); ?></b></h2>
									<a class="open-modal" href="<?php echo e(route('detalle_raza_without_auth', ['raza' => $raza->id, 'mode' => 'H'])); ?>" style= "color:#00BFFF; font-size:18px;: Georgia, 'Times New Roman', serif;">Historia</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				     				<a class="open-modal" href="<?php echo e(route('detalle_raza_without_auth', ['raza' => $raza->id, 'mode' => 'C'])); ?>" style= "color:#00BFFF; font-size:18px;: Georgia, 'Times New Roman', serif;" >Caracteristicas</a><br><br>
								</section>
							</section>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</section>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>