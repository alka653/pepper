<li>
	<a href="<?php echo e(route('listar_mascota')); ?>">Mascotas</a>
</li>
<li>
	<a href="<?php echo e(route('listar_solicitudes')); ?>">Solicitudes</a>
</li>
<li>
	<a href="#">Ataques</a>
</li>
<li class="menu-has-children"><a href="">Drop Down</a>
	<ul>
		<li><a href="#">Drop Down 1</a></li>
		<li><a href="#">Drop Down 3</a></li>
		<li><a href="#">Drop Down 4</a></li>
		<li><a href="#">Drop Down 5</a></li>
	</ul>
</li>