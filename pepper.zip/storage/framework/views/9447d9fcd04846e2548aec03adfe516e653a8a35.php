<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<h2 class="text-center">
			<?php echo e($mascota->nombre); ?>

			<a href="<?php echo e(route('editar_mascota', ['mascota' => $mascota->id])); ?>" class="btn btn-sm btn-warning">Editar</a>
		</h2>
		<div class="row justify-content-md-center align-items-center">
			<?php $__currentLoopData = $mascota->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-2">
					<img src="<?php echo e(Storage::url($foto->foto)); ?>" alt="<?php echo e($mascota->nombre); ?>" class="img-fluid rounded">
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div class="col-12" style="margin: 10px 0px;">
				<div class="block">
					<div class="table-responsive">
						<table class="table table-striped table-sm">
							<tr>
								<th>Fecha de nacimiento</th>
								<td><?php echo e($mascota->fecha_nacimiento); ?></td>
							</tr>
							<tr>
								<th>Sexo</th>
								<td><?php echo e($mascota->getSexo($mascota->sexo)); ?></td>
							</tr>
							<tr>
								<th>Color</th>
								<td><?php echo e($mascota->color); ?></td>
							</tr>
							<tr>
								<th>Descripción</th>
								<td><?php echo e($mascota->descripcion); ?></td>
							</tr>
							<tr>
								<th>Estado</th>
								<td><?php echo e($mascota->estado); ?></td>
							</tr>
							<tr>
								<th>Vacunado</th>
								<td><?php echo e($mascota->vacunado == 1 ? "Si. Fecha de vacunación: {$mascota->fecha_vacunacion}" : 'No'); ?></td>
							</tr>
							<tr>
								<th>Raza</th>
								<td><?php echo e($mascota->raza->nombre); ?></td>
							</tr>
						</table>
					</div>
				</div>
			</div>
			<div class="col-12" style="margin: 10px 0px;">
				<h4 class="text-center">Certificados</h4>
				<div class="block">
					<table class="table">
						<thead>
							<tr>
								<th>Fecha remisión</th>
								<th>Fecha vencimiento</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $mascota->certificados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td><?php echo e($certificado->fecha_remitido); ?></td>
									<td><?php echo e($certificado->fecha_vencimiento); ?></td>
									<td>
										<a href="#" class="btn btn-sm btn-success">Descargar el certificado</a>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<tr>
									<td class="text-center" colspan="3">
										<?php if(auth()->check() && auth()->user()->hasRole('guest')): ?>
											<?php echo e($mascota->nombre); ?> aún no tiene certificado. Da <a href="<?php echo e(route('crear_solicitud')); ?>?mascota=<?php echo e($mascota->id); ?>">clic aquí</a> para hacer la solicitud.
										<?php else: ?>
											Sin certificados
										<?php endif; ?>
									</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>