<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 10px; padding-bottom: 30px;">
		<h2>Regístrate en Pepper</h2>
		<div class="block">
			<?php echo e(Form::open(['url' => route('crear_cuenta.post'), 'method' => 'post', 'autocomplete' => 'off', 'enctype' => 'multipart/form-data'])); ?>

				<div class="row">
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('nombre', 'Nombre', ['class' => 'label-required'])); ?>

						<?php echo e(Form::text('nombre', null, ['required', 'class' => 'form-control'])); ?>

						<?php echo $errors->first('nombre', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('apellido', 'Apellido', ['class' => 'label-required'])); ?>

						<?php echo e(Form::text('apellido', null, ['required', 'class' => 'form-control'])); ?>

						<?php echo $errors->first('apellido', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('tipo_documento', 'Tipo de documento', ['class' => 'label-required'])); ?>

						<?php echo e(Form::select('tipo_documento', [
							'' => 'Seleccione una opción',
							'TI' => 'Tarjeta de identidad',
							'CC' => 'Cédula de ciudadanía',
							'CE' => 'Cédula extranjera',
							'PS' => 'Pasaporte'
						], null, ['required', 'class' => 'form-control'])); ?>

						<?php echo $errors->first('tipo_documento', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('numero_documento', 'Número del documento', ['class' => 'label-required'])); ?>

						<?php echo e(Form::text('numero_documento', null, ['required', 'class' => 'form-control only-number'])); ?>

						<?php echo $errors->first('numero_documento', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('departamento_expedicion_id', 'Departamento expedición documento', ['class' => 'label-required'])); ?>

						<?php echo e(Form::select('departamento_expedicion_id', $departamentoLista, null, ['required', 'class' => 'form-control select2 departamento_change'])); ?>

						<?php echo $errors->first('departamento_expedicion_id', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('municipio_expedicion_id', 'Municipio expedición documento', ['class' => 'label-required'])); ?>

						<?php echo e(Form::select('municipio_expedicion_id', [], null, ['required', 'class' => 'form-control select2'])); ?>

						<?php echo $errors->first('municipio_expedicion_id', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('direccion_residencia', 'Dirección de residencia', ['class' => 'label-required'])); ?>

						<?php echo e(Form::text('direccion_residencia', null, ['required', 'class' => 'form-control'])); ?>

						<?php echo $errors->first('direccion_residencia', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('departamento_residencia_id', 'Departamento residencia', ['class' => 'label-required'])); ?>

						<?php echo e(Form::select('departamento_residencia_id', $departamentoLista, null, ['required', 'class' => 'form-control select2 departamento_change'])); ?>

						<?php echo $errors->first('departamento_residencia_id', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('municipio_residencia_id', 'Municipio residencia', ['class' => 'label-required'])); ?>

						<?php echo e(Form::select('municipio_residencia_id', [], null, ['required', 'class' => 'form-control select2'])); ?>

						<?php echo $errors->first('municipio_residencia_id', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('email', 'Correo electrónico', ['class' => 'label-required'])); ?>

						<?php echo e(Form::email('email', null, ['required', 'class' => 'form-control'])); ?>

						<?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('sexo', 'Sexo', ['class' => 'label-required'])); ?>

						<?php echo e(Form::select('sexo', [
							'' => 'Seleccione una opción',
							'M' => 'Masculino',
							'F' => 'Femenino'
						], null, ['required', 'class' => 'form-control select2'])); ?>

						<?php echo $errors->first('sexo', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('numero_celular', 'Número celular', ['class' => 'label-required'])); ?>

						<?php echo e(Form::text('numero_celular', null, ['required', 'class' => 'form-control only-number'])); ?>

						<?php echo $errors->first('numero_celular', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('numero_telefonico', 'Número telefónico')); ?>

						<?php echo e(Form::text('numero_telefonico', null, ['class' => 'form-control only-number'])); ?>

						<?php echo $errors->first('numero_telefonico', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<?php echo e(Form::label('ocupacion', 'Ocupación', ['class' => 'label-required'])); ?>

						<?php echo e(Form::text('ocupacion', null, ['required', 'class' => 'form-control'])); ?>

						<?php echo $errors->first('ocupacion', '<p class="help-block">:message</p>'); ?>

					</div>
					<div class="col-md-6 form-group">
						<div class="custom-file">
							<?php echo e(Form::file('foto', ['class' => 'custom-file-input', 'accept' => 'image/*'])); ?>

							<?php echo e(Form::label('foto', 'Foto', ['class' => 'custom-file-label'])); ?>

							<?php echo $errors->first('foto', '<p class="help-block">:message</p>'); ?>

						</div>
					</div>
					<div class="col-12 form-group text-center">
						<?php echo Form::button('Enviar datos', ['type' => 'submit', 'class' => 'btn btn-primary']); ?>

					</div>
				</div>
			<?php echo e(Form::close()); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>