<li>
	<a href="<?php echo e(route('listar_mascota')); ?>">Mascotas</a>
</li>
<li>
	<a href="<?php echo e(route('listar_solicitudes')); ?>">Solicitudes</a>
</li>
<li>
	<a href="<?php echo e(route('listar_ataques')); ?>">Ataques</a>
</li>
<?php if(auth()->check() && auth()->user()->hasRole('administrator')): ?>
	<li class="menu-has-children">
		<a href="#" class="sf-with-ul">Configuración</a>
		<ul>
			<li>
				<a href="<?php echo e(route('listar_razas_with_auth')); ?>">Razas</a>
			</li>
			<li>
				<a href="<?php echo e(route('listar_tipos_ataques')); ?>">Tipos de ataques</a>
			</li>
			<li>
				<a href="<?php echo e(route('listar_localizaciones_anatomicas')); ?>">Localizaciones anatómicas</a>
			</li>
		</ul>
	</li>
<?php endif; ?>