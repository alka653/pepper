<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
		.block{
			margin-top: 15%;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 20px">
		<div class="row justify-content-md-center">
			<div class="col-md-5">
				<div class="block">
					<h4>Ingreso a PEPPER</h4>
					<?php echo e(Form::open(['url' => route('login.post'), 'method' => 'post'])); ?>

						<div class="form-group">
							<?php echo e(Form::label('email', 'Nombre de usuario')); ?>

							<?php echo e(Form::text('email', null, ['required', 'class' => 'form-control'])); ?>

							<?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

						</div>
						<div class="form-group">
							<?php echo e(Form::label('password', 'Contraseña')); ?>

							<?php echo e(Form::password('password', ['required', 'class' => 'form-control'])); ?>

							<?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

						</div>
						<div class="form-group">
							<div class="custom-control custom-checkbox">
								<?php echo e(Form::checkbox('remember', false, old('remember'), ['class' => 'custom-control-input', 'id' => 'remember'])); ?>

								<?php echo e(Form::label('remember', 'Recordar acceso', ['class' => 'custom-control-label'])); ?>

							</div>
						</div>
						<div class="form-group text-center">
							<?php echo Form::button('Acceder', ['type' => 'submit', 'class' => 'btn btn-primary']); ?>

						</div>
					<?php echo e(Form::close()); ?>

				</div>
				<p class="text-center"><a href="<?php echo e(route('crear_cuenta')); ?>">Crear cuenta</a></p>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script>
		$(document).ready(function(){
			localStorage.removeItem('municipio_expedicion_id')
			localStorage.removeItem('municipio_residencia_id')
		})
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>