<?php $__env->startSection('style'); ?>
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-bottom: 100px">
		<div class="row justify-content-md-center">
			<div class="col-md-4 block">
				<img src="<?php echo e($raza->foto); ?>" class="img-fluid">
			</div>
		</div>
		<h2 class="text-center"><?php echo e($raza->nombre); ?></h2>
		<?php echo $raza->descripcion; ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>