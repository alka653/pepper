Hola, <?php echo e($user->nombre); ?> <?php echo e($user->apellido); ?>


<?php echo $user->message; ?>


<?php echo e(route('login')); ?>