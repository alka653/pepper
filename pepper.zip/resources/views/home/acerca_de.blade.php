<div class="modal-dialog" role="document">
	<div class="modal-content">
		<div class="modal-header">
			<h5 class="modal-title">Sobre el uso de imágenes</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
		<div class="modal-body text-justify">
			<p>
				Las imágenes utilizadas para la realización de esta página fueron tomadas de Freepik el cual es un motor de búsqueda de imágenes libres que ayuda a los diseñadores gráficos y de web a localizar fotos de alta calidad, imágenes vectoriales, ilustraciones y archivos PSD. Aclarando que no todas las imágenes fueron tomadas de esta sitio, debido a que son autoría propia.
			</p>
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
		</div>
	</div>
</div>