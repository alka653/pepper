@extends('layouts.app')

@section('style')
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
@endsection

@section('content')
	<div class="container text-center" style="margin-top: 10%; margin-bottom: 50px;">
		<h1>Algo ha ocurrido!</h1>
		<h4>Parece que no tienes acceso al recurso en pantalla. Si crees que se trata de un error, contacta al admnistrador.</h4>
	</div>
@endsection