@extends('layouts.app')

@section('style')
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
@endsection

@section('content')
	<div class="container" style="margin-bottom: 100px">
		<div class="block">
			<h2>Edición de datos personales</h2>
			<div class="row">
			</div>
		</div>
	</div>
@endsection