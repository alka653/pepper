<li class="menu-has-children">
	<a href="#" class="sf-with-ul">Mascotas</a>
	<ul>
		<li>
			<a href="{{ route('listar_mascota') }}">Mis mascotas</a>
		</li>
		<li>
			<a href="{{ route('listar_solicitudes') }}">Solicitudes</a>
		</li>
	</ul>
</li>