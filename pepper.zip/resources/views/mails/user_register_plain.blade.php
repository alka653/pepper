Hola, {{ $user->nombre }} {{ $user->apellido }}

Gracias por registrarse en Pepper.
Ingresa ya para registrar a una mascota.

{{ route('login') }}