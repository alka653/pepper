Hola, {{ $user->nombre }} {{ $user->apellido }}

{!! $user->message !!}

{{ route('login') }}