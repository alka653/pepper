<div bgcolor="#f3f3f3" style="margin:5px 0 0 0;padding:0;background-color:#f3f3f3">
	<table bgcolor="#f3f3f3" border="0" cellpadding="0" cellspacing="0" style="color:#4a4a4a;font-family:'Museo Sans Rounded',Museo Sans Rounded,'Museo Sans',Museo Sans,'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:14px;line-height:20px;border-collapse:callapse;border-spacing:0;margin:0 auto;" width="100%">
		<tbody>
			<tr>
				<td style="padding-left:10px;padding-right:10px">
					<table align="center" border="0" cellpadding="0" cellspacing="0" class="m_304056208632991473main" style="width:100%;margin:0 auto;max-width:600px;padding-top:3%;" width="100%">
						<tbody>
							<tr>
								<td bgcolor="#ffffff" style="background-color:#ffffff;padding:9%">
									<table border="0" cellpadding="0" cellspacing="0" style="width:100%">
										<tbody>
											<tr>
												<td style="background-color:#ffffff">
													@yield('content')
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td border="0" cellpadding="0" cellspacing="0" style="padding:20px 0" width="100%">
									<table border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse" width="100%">
										<tbody>
											<tr>
												<td class="m_304056208632991473unsubscribe" style="padding:20px" width="100%">
													<div style="margin:0;text-align:center;font-size:12px;color:#bbbbbb">
														Si recibió este correo por error, por favor ignorarlo.
													</div>
													<div style="margin:0;font-size:11px;text-align:center;color:#bbbbbb">
														© 2018 Pepper
													</div>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
</div>