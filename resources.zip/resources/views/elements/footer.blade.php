<footer id="footer">
	<div class="container">
		<div class="copyright">
			&copy; Copyright <strong>PEPPER</strong>. Todos los derechos reservados
		</div>
	</div>
</footer>