@extends('layouts.app')

@section('style')
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
@endsection

@section('content')
	<div class="container" style="margin-bottom: 100px">
		<h2 class="text-center">Perros potencialmente peligrosos</h2>
		<div class="row justify-content-md-center">
			@foreach($razas as $raza)
				<div class="col-md-3">
					<div class="block">
						<a href="{{ route('detalle_raza_without_auth', ['raza' => $raza->id]) }}">
							<div class="text-center row">
								<div class="col-12">
									<img src="{{ $raza->foto }}" class="img-fluid">
								</div>
								<div class="col-12">
									{{ $raza->nombre }}
								</div>
							</div>
						</a>
					</div>
				</div>
			@endforeach
			<div class="col-12">
				{{ $razas->links() }}
			</div>
		</div>
	</div>
@endsection