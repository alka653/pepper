@extends('layouts.app')

@section('style')
	<style type="text/css" media="screen">
		body{
			background-color: #f2f5f8;
		}
	</style>
@endsection

@section('content')
	<div class="container" style="margin-bottom: 100px">
		<div class="row justify-content-md-center">
			<div class="col-md-4 block">
				<img src="{{ $raza->foto }}" class="img-fluid">
			</div>
		</div>
		<h2 class="text-center">{{ $raza->nombre }}</h2>
		{!! $raza->descripcion !!}
	</div>
@endsection