Estimado usuario

{!! $user->message !!}

{{ route('home') }}