<header>
    <div class="row text-center">
        <div class="col-1" style="width: 10%">
            <img src="{{ $logo }}" class="img-fluid">
        </div>
        <div class="col-8 text-center" style="margin-left: 15%">
            <h5>
                <b>SISTEMA DE INFORMACIÓN PARA EL REGISTRO Y CONTROL DE LOS PERROS POTENCIALMENTE PELIGROSOS (PEPPER)</b>
            </h5>
        </div>
        <div class="col-1" style="margin-left: 85%">
            <img src="{{ $escudo }}" class="img-fluid">
        </div>
    </div>
</header>