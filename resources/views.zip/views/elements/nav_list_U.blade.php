<li class="menu-has-children">
	<a href="#" class="sf-with-ul">Mascotas</a>
	<ul>
		<li>
			<a href="{{ route('crear_mascota') }}">Crear</a>
		</li>
		<li>
			<a href="{{ route('listar_mascota') }}">Listar</a>
		</li>
	</ul>
</li>
<li>
	<a href="{{ route('listar_certificados') }}">Certificados</a>
</li>
<li>
	<a href="{{ route('listar_ataques') }}">Ataques</a>
</li>
<li class="menu-has-children">
	<a href="#" class="sf-with-ul">Solicitudes</a>
	<ul>
		<li>
			<a href="{{ route('crear_solicitud') }}">Crear</a>
		</li>
		<li>
			<a href="{{ route('listar_solicitudes') }}">Listar</a>
		</li>
	</ul>
</li>