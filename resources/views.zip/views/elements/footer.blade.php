<br><br><br><br>
<footer id="footer">
	<div class="container">
		<div class="copyright">
			<div class="row align-items-center justify-content-md-center">
				<div class="col-6 col-sm-3 col-md-2">
					<a href="http://www.cundinamarca.gov.co/" target="_blank">
						<img src="/img/footer/gober.png" class="img-fluid">
					</a>
				</div>
				<div class="col-6 col-sm-3 col-md-2">
					<a href="https://www.dnp.gov.co/DNPN/Paginas/default.aspx" target="_blank">
						<img src="/img/footer/gobierno.png" class="img-fluid">
					</a>
				</div>
				<div class="col-6 col-sm-3 col-md-2">
					<a href="http://www.colciencias.gov.co/" target="_blank">
						<img src="/img/footer/col.png" class="img-fluid">
					</a>
				</div>
				<div class="col-6 col-sm-3 col-md-2">
					<a href="http://estrategia.gobiernoenlinea.gov.co/623/w3-channel.html" target="_blank">
						<img src="/img/footer/linea.jpg" class="img-fluid">
					</a>
				</div>
				<div class="col-6 col-sm-3 col-md-2">
					<a href="https://www.mineducacion.gov.co/portal/" target="_blank">
						<img src="/img/footer/MIN.png" class="img-fluid">
					</a>
				</div>
			</div>
			&copy; Copyright <strong>PEPPER</strong>. Todos los derechos reservados
		</div>
	</div>
</footer>