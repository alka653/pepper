<div class="modal-dialog" role="document">
	<div class="modal-content">
		<div class="modal-header">
			<h5 class="modal-title">Licencias</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
		<div class="modal-body text-justify">
			<h5>
				<b>Sobre el uso de imágenes</b>
			</h5>
			<p>
				Las imágenes utilizadas para la realización de esta página fueron tomadas de Freepik el cual es un motor de búsqueda de imágenes libres que ayuda a los diseñadores gráficos y de web a localizar fotos de alta calidad, imágenes vectoriales, ilustraciones y archivos PSD. Aclarando que no todas las imágenes fueron tomadas de esta sitio, debido a que son autoría propia.
			</p>
			<h5>
				<b>Sobre el uso de del software</b>
			</h5>
			<p>
				Para el funcionamiento de esta aplicación se requiere un navegador web google chrome y conexión a internet.
			</p>
			<p>	
				Si desea adquirir el certificado para su mascota de razas potencialmente peligrosas debe registrarse en nuestro sistema.
			</p>
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
		</div>
	</div>
</div>